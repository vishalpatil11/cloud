package file.test
import java.io.File
import org.apache.spark.sql.SparkSession
import com.typesafe.config._
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.hadoop.fs.{FileSystem, Path}

object FileListing {

/*  //Load parameters from application.properties file using Config Factory
  val props = ConfigFactory.load()
  val masterURL = props.getString("masterURL")
  val appDescription = props.getString("appNameCSVtoAVRO")
  val gcsInputPath = props.getString("csvInputPath")
  val gcsOutputPath = props.getString("avroOutputPath")
  val csvSchema = props.getString("csvSchema")
  val csvDelimeter = props.getString("csvDelimeter")*/

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .master("local[1]")
    // .master(masterURL)
    // .appName("file listing from directory")
    //  .getOrCreate();



/*val p = "gs://cg-test-avro/input-csv"

val path = new Path(p)
val fs = path.getFileSystem(p)
fs.exists(path)

fs.isDirectory(path)*/
      
      
/*    def getListOfFiles(dir: String): List[File] = {
      val d = new File(dir)
      if (d.exists && d.isDirectory) {
        d.listFiles.filter(_.isFile).toList
      } else {
        List[File]()
      }
    }
    
    val files = getListOfFiles("/input")*/


  }
}