package gcp.dataproc.spark

import org.apache.spark.sql.types.LongType
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import com.typesafe.config._
import com.miraisolutions.spark.bigquery.config._
import org.apache.spark.sql.SaveMode

object CsvToBQusingAvroJob {

  def main(args: Array[String]) {

    //Load parameters from application.properties file using Config Factory
    val props = ConfigFactory.load()
    val masterURL = props.getString("masterURL")
    val appDescription = props.getString("appNameCSVtoAVRO")
    //    val gcsInputPath = props.getString("csvInputPath")
    //    val gcsInputDir = props.getString("csvInputPath")
    //    val gcsOutputPath = props.getString("avroOutputPath")
    //    val csvSchema = props.getString("csvSchema")
    val csvDelimeter = props.getString("csvDelimeter")
    val outputStorageFormat = props.getString("storageFormat")
    //    val outputBigQueryTable = props.getString("bigQueryTable")
    val bigQueryProjIDDataSet = props.getString("bigQueryTable")
    val saveModeType = props.getString("saveMode")
    //    val gcsAvroInputPath = props.getString("avroInputPath")
    val gcpProjectID = props.getString("projectID")
    val gcpProjectLocation = props.getString("projectLocation")
    val gcsBucketLocation = props.getString("bucketLocation")
    val sqlQuery = props.getString("sqlQuery")

    // initialize Spark session
    val spark = SparkSession
      .builder()
      //.master("local[1]")
      .master(masterURL)
      .appName(appDescription)
      .getOrCreate();

    val inputFileName = args(0)
    val gcsInputDir = args(1)
    val gcsOutputPath = args(2)

    val gcsAvroInputPath = gcsOutputPath.concat("/part*.avro")

    val inputFile = inputFileName.concat("*")
    //    val inputFile = inputFileName.concat("*.csv")
    val gcsInputPath = gcsInputDir.concat("/").concat(inputFile)
    val outputBigQueryTable = bigQueryProjIDDataSet.concat(".").concat(inputFileName)

    // Schema creation
    val customSchema = StructType(Array(
      StructField("department", StringType, true),
      StructField("designation", StringType, true),
      StructField("ctc", LongType, true),
      StructField("state", StringType, true)))

     // Reading CSV file
    val readCSV = spark.read.format("com.databricks.spark.csv")
      .option("header", true)
      .option("delimiter", csvDelimeter)
      .option("quote","")
//      .option("inferSchema", "false")
      .schema(customSchema)
      //  .option("schema", "Department: string ,Designation: string ,costToCompany: integer ,State: string")
      .load(gcsInputPath)
      //.csv(gcsInputPath)
      
   /* // Reading CSV file
    val readCSV = spark.read.option("header", true)
      .option("delimiter", csvDelimeter)
      .option("quote","")
//      .option("inferSchema", "false")
      .schema(customSchema)
      //  .option("schema", "Department: string ,Designation: string ,costToCompany: integer ,State: string")
      .csv(gcsInputPath)*/

    readCSV.printSchema()
    readCSV.show()

    // Writing CSV to AVRO
    readCSV.write.format("com.databricks.spark.avro")
      .save(gcsOutputPath)

    // Define BigQuery options
    val config = BigQueryConfig(
      project = (gcpProjectID),
      location = (gcpProjectLocation),
      stagingDataset = StagingDatasetConfig(gcsBucket = (gcsBucketLocation)))

    // Reading AVRO file
    val readAVRO = spark.read.format("com.databricks.spark.avro")
      .load(gcsAvroInputPath)

    //PrintSchema
    readAVRO.printSchema()

    //Show sample records
    readAVRO.show()

    // Register as Temp Table
    readAVRO.createOrReplaceTempView("Emp_Data")

    // Apply Filter
    val dataFilter = spark.sql(sqlQuery)

    //PrintSchema
    dataFilter.printSchema()

    //Show sample records
    dataFilter.show()

    // Write data To Big Query Table
    dataFilter.write
      .bigquery(config)
      .option("table", outputBigQueryTable)
      .option("type", outputStorageFormat)
      .mode(saveModeType)
      .save()

  }
}