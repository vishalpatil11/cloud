package gcp.dataproc.spark

import org.apache.spark.sql.SparkSession
import com.miraisolutions.spark.bigquery.config._
import org.apache.spark.sql.SaveMode
import com.typesafe.config.ConfigFactory

object AvroToBigQueryJob {
  def main(args: Array[String]): Unit = {

    // Load parameters from application.properties file using Config Factory
    val props = ConfigFactory.load()
    val masterURL = props.getString("masterURL")
    val appDescription = props.getString("appNameAVROtoBigQuery")
    val outputStorageFormat = props.getString("storageFormat")
    val outputBigQueryTable = props.getString("bigQueryTable")
    val saveModeType = props.getString("saveMode")
    val gcsInputPath = props.getString("avroInputPath")
    val gcpProjectID = props.getString("projectID")
    val gcpProjectLocation = props.getString("projectLocation")
    val gcsBucketLocation = props.getString("bucketLocation")
    val sqlQuery = props.getString("sqlQuery")
        
    // Initialize Spark session
    val spark = SparkSession
      .builder
      .master(masterURL)
      .appName(appDescription)
      .getOrCreate

    // Define BigQuery options
    val config = BigQueryConfig(
      project = (gcpProjectID),
      location = (gcpProjectLocation),
      stagingDataset = StagingDatasetConfig(gcsBucket = (gcsBucketLocation)))

    // Reading AVRO file  
    val readAVRO = spark.read.format("com.databricks.spark.avro")
      .load(gcsInputPath)

    //PrintSchema
    readAVRO.printSchema()

    //Show sample records
    readAVRO.show()

    // Register as Temp Table
    readAVRO.createOrReplaceTempView("Emp_Data")

    // Apply Filter
    val dataFilter = spark.sql(sqlQuery)

    //PrintSchema
    dataFilter.printSchema()

    //Show sample records
    dataFilter.show()
    
    // Write data To Big Query Table
    dataFilter.write
      .bigquery(config)
      .option("table", outputBigQueryTable)
      .option("type", outputStorageFormat)
      .mode(saveModeType)
      .save()

  }
}