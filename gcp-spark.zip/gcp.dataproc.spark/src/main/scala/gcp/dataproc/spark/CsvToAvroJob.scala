package gcp.dataproc.spark

import org.apache.spark.sql.types.LongType
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import com.typesafe.config._

object CsvToAvroJob {

  def main(args: Array[String]) {

    //Load parameters from application.properties file using Config Factory
    val props = ConfigFactory.load()
    val masterURL = props.getString("masterURL")
    val appDescription = props.getString("appNameCSVtoAVRO")
    val gcsInputPath = props.getString("csvInputPath")
    val gcsOutputPath = props.getString("avroOutputPath")
    val csvSchema = props.getString("csvSchema")
    val csvDelimeter = props.getString("csvDelimeter")

    // initialize Spark session
    val spark = SparkSession
      .builder()
      //.master("local[1]")
      .master(masterURL)
      .appName(appDescription)
      .getOrCreate();

    // Reading CSV file
    val readCSV = spark.read.option("header", true)
    
      // .schema(customSchema)
      .option("schema", csvSchema)
      .option("delimiter", csvDelimeter)
      .csv(gcsInputPath)
    readCSV.show()

    // Writing CSV to AVRO
    readCSV.write.format("com.databricks.spark.avro")
      .save(gcsOutputPath)

  }
}